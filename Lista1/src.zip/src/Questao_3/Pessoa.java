package Questao_3;

public class Pessoa {
    private float massa;

    public float getMassa() {
        return massa;
    }

    public void setMassa(float novaMassa) {
        massa = novaMassa;
    }
}