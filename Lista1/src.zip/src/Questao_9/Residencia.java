package Questao_9;

public class Residencia {
    private float energiaConsumida;

    public float getEnergiaConsumida() {
        return energiaConsumida;
    }

    public void setEnergiaConsumida(float energiaConsumida) {
        this.energiaConsumida = energiaConsumida;
    }
}
